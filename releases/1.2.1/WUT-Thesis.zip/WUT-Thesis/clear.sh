#!/bin/bash

rm *.aux *.bbl *.blg *.gz *.lof *.log *.lot *.out *.pdf *.toc *.xml
